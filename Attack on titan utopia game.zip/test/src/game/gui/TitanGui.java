package game.gui;

import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javafx.animation.FadeTransition;

public class TitanGui {
	private Titan titan;
	private Image image;
	private ImageView imview;
	private Label label;
	private AnchorPane titanpane;
	
	public TitanGui(Titan titan) {
		this.titan=titan;
		if (titan instanceof PureTitan)
			this.image = new Image("Pure Titan.png");
		if (titan instanceof AbnormalTitan)
			this.image = new Image("Abnormal Titan.jpeg");
		if (titan instanceof ArmoredTitan)
			this.image = new Image("Armored Titan.jpeg");
		if (titan instanceof ColossalTitan)
			this.image = new Image("colossal_Titan.png");
		imview = new ImageView(image);
		label = new Label(""+titan.getCurrentHealth());
		titanpane = new AnchorPane();
		titanpane.getChildren().addAll(imview,label);
		if (titan instanceof PureTitan) {
			imview.setFitWidth(50);
			imview.setFitHeight(30);
		}
		if (titan instanceof AbnormalTitan) {
			imview.setFitWidth(50);
			imview.setFitHeight(20);
		}
		if (titan instanceof ArmoredTitan) {
			imview.setFitWidth(50);
			imview.setFitHeight(30);
		}
		if (titan instanceof ColossalTitan) {
			imview.setFitWidth(50);
			imview.setFitHeight(90);
		}

	}
	
	public Titan getTitan() {
		return titan;
	}

	public Image getImage() {
		return image;
	}

	public ImageView getImview() {
		return imview;
	}
	
	public Label getLabel() {
		return label;
	}

	public AnchorPane getTitanpane() {
		return titanpane;
	}
	public void setTitanpane(AnchorPane titanpane) {
		this.titanpane = titanpane;
	}
	public void updatelabel() {
		label.setText(""+titan.getCurrentHealth());
	}

	public void moveremove() {
		Object FadeTransition;
		if (titan.getCurrentHealth()==0) {
			FadeTransition fadeout= new FadeTransition();
		 	fadeout.setDuration(Duration.millis(500));
		 	fadeout.setNode(titanpane);
		 	fadeout.setFromValue(1);
		 	fadeout.setToValue(0);
		 	fadeout.play();
		}
		else {
			if(titan.getDistance()>titan.getSpeed()) {
				titanpane.setLayoutX(titanpane.getLayoutX()+titan.getSpeed()*6.6);
			}
			else if(titan.getDistance()>0) {
				titanpane.setLayoutX(660);
			}
			
		}
	}

}
