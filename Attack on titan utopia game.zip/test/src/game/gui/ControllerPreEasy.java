package game.gui;

import java.io.IOException;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ControllerPreEasy {
Button OK;
Parent root;
Stage stage;
Scene scene;
AnchorPane anchorpane;
public void start(ActionEvent e) {
	try {
		root = FXMLLoader.load(getClass().getResource("Easy.fxml"));
	} catch (IOException e1) {
		e1.printStackTrace();
	}
	 stage = (Stage)((Node)e.getSource()).getScene().getWindow();
	 scene = new Scene(root);
	 stage.setScene(scene);
	 stage.show();
	 }
}
